package com.infstock;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.regex.Pattern;

public class InfStockMod implements ClientModInitializer {
    // Matches "Stock: 1", "Stock: 2", "Stock: 3" (not 0, not 10+)
    private static final Pattern STOCK = Pattern.compile("Stock:\\s*[1-3](?!\\d)");
    private static final int DELAY_TICKS = 10;      // 0.5 second (20 ticks = 1s)
    private static final long COOLDOWN_MS = 3000;   // avoid double-sending

    private static volatile boolean enabled = true;
    private static int pending = 0;
    private static long lastTrigger = 0;

    @Override
    public void onInitializeClient() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay || !enabled) return;
            String text = message.getString();
            if (text.startsWith("<")) return; // ignore normal player chat
            if (!STOCK.matcher(text).find()) return;
            long now = System.currentTimeMillis();
            if (now - lastTrigger < COOLDOWN_MS || pending > 0) return;
            lastTrigger = now;
            pending = DELAY_TICKS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (pending > 0 && --pending == 0) {
                if (enabled && mc.player != null && mc.player.connection != null) {
                    mc.player.connection.sendChat("all");
                }
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> register(dispatcher));
    }

    private static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(ClientCommandManager.literal("inf")
            .then(ClientCommandManager.literal("on").executes(ctx -> {
                enabled = true;
                ctx.getSource().sendFeedback(Component.literal("§aINF: ON"));
                return 1;
            }))
            .then(ClientCommandManager.literal("off").executes(ctx -> {
                enabled = false;
                pending = 0;
                ctx.getSource().sendFeedback(Component.literal("§cINF: OFF"));
                return 1;
            })));
    }
}
