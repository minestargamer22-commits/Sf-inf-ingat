package ir.autoall;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.Text;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AutoAllMod implements ClientModInitializer {

    private static final Pattern ITEM = Pattern.compile("Item:\\s*Infinity\\s*Ingot", Pattern.CASE_INSENSITIVE);
    private static final Pattern STOCK = Pattern.compile("Stock:\\D*(\\d+)", Pattern.CASE_INSENSITIVE);

    private static final int MIN_STOCK = 1;
    private static final int MAX_STOCK = 3;
    private static final long ITEM_WINDOW_MS = 3000;
    private static final long COOLDOWN_MS = 1500;

    private volatile boolean enabled = false;
    private long itemSeenAt = -1;
    private long lastSent = 0;

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("inf-bot")
                .then(ClientCommandManager.literal("on").executes(ctx -> {
                    enabled = true;
                    ctx.getSource().sendFeedback(Text.literal("Inf-bot: ON"));
                    return Command.SINGLE_SUCCESS;
                }))
                .then(ClientCommandManager.literal("off").executes(ctx -> {
                    enabled = false;
                    itemSeenAt = -1;
                    ctx.getSource().sendFeedback(Text.literal("Inf-bot: OFF"));
                    return Command.SINGLE_SUCCESS;
                }))
            )
        );

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) handle(message.getString());
        });
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, ts) -> handle(message.getString()));
    }

    private synchronized void handle(String text) {
        if (!enabled) return;
        long now = System.currentTimeMillis();
        // Remove legacy color codes (like §e, §9) that may be inside the raw text
        text = text.replaceAll("\u00A7.", "");
        for (String line : text.split("\\R")) {
            if (ITEM.matcher(line).find()) {
                itemSeenAt = now;
            }
            Matcher m = STOCK.matcher(line);
            if (m.find() && itemSeenAt > 0 && now - itemSeenAt <= ITEM_WINDOW_MS) {
                int stock;
                try {
                    stock = Integer.parseInt(m.group(1));
                } catch (NumberFormatException e) {
                    continue;
                }
                if (stock >= MIN_STOCK && stock <= MAX_STOCK && now - lastSent > COOLDOWN_MS) {
                    lastSent = now;
                    itemSeenAt = -1;
                    sendAll();
                }
            }
        }
    }

    private void sendAll() {
        MinecraftClient client = MinecraftClient.getInstance();
        client.execute(() -> {
            ClientPlayNetworkHandler handler = client.getNetworkHandler();
            if (handler != null) {
                handler.sendChatMessage("all");
            }
        });
    }
}
