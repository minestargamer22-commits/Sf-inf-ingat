package com.infstock;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InfStockClient implements ClientModInitializer {

    /** "Stock: 1" / "Stock: 2" / "Stock: 3"  (Stock: 0 و بالای 3 جواب داده نمیشه) */
    private static final Pattern STOCK = Pattern.compile("(?i)stock\\s*:\\s*([1-3])(?!\\d)");

    /** پیامی که پلیر می‌نویسه */
    private static final String REPLY = "all";

    /** تاخیر قبل از نوشتن پیام (میلی‌ثانیه). 1000 = 1 ثانیه */
    private static final long DELAY_MS = 1000L;

    private static volatile boolean enabled = true;
    private static volatile boolean checkColors = true;
    private static long sendAt = -1L;

    @Override
    public void onInitializeClient() {
        // پیام‌های سیستمی سرور (پلاگین‌ها معمولا از این مسیر میان)
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) {
                onMessage(message);
            }
        });
        // پیام‌های چت عادی
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, timestamp) -> onMessage(message));

        ClientTickEvents.END_CLIENT_TICK.register(InfStockClient::onTick);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> registerCommands(dispatcher));
    }

    // ------------------------------------------------------------------ chat

    private static void onMessage(Component message) {
        try {
            if (!enabled || sendAt >= 0) {
                return; // خاموشه، یا یه پیام در صف ارسال هست (جلوگیری از اسپم)
            }
            if (matches(message)) {
                sendAt = System.currentTimeMillis() + DELAY_MS;
            }
        } catch (Throwable ignored) {
            // هیچ‌وقت نذار ماد باعث کرش بشه
        }
    }

    private static void onTick(Minecraft mc) {
        if (sendAt < 0) {
            return;
        }
        if (!enabled) {
            sendAt = -1L;
            return;
        }
        if (System.currentTimeMillis() < sendAt) {
            return;
        }
        sendAt = -1L;
        ClientPacketListener connection = mc.getConnection();
        if (connection != null && mc.player != null) {
            connection.sendChat(REPLY);
        }
    }

    // ---------------------------------------------------------------- matching

    private static boolean matches(Component message) {
        StringBuilder text = new StringBuilder();
        List<Integer> colors = new ArrayList<>();

        message.visit((style, str) -> {
            TextColor c = style.getColor();
            int rgb = c == null ? -1 : c.getValue();
            for (int i = 0; i < str.length(); i++) {
                text.append(str.charAt(i));
                colors.add(rgb);
            }
            return Optional.<Boolean>empty();
        }, Style.EMPTY);

        Matcher m = STOCK.matcher(text);
        while (m.find()) {
            if (!checkColors) {
                return true;
            }
            int stockColor = colors.get(m.start());   // رنگ کلمه Stock:  (سبز)
            int numberColor = colors.get(m.start(1)); // رنگ عدد          (زرد)
            if (isGreen(stockColor) && isYellow(numberColor)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isGreen(int rgb) {
        if (rgb < 0) return false;
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        return g >= 0xAA && g > r + 0x40 && g > b + 0x40;
    }

    private static boolean isYellow(int rgb) {
        if (rgb < 0) return false;
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        return r >= 0xAA && g >= 0xAA && b <= 0x80;
    }

    // ---------------------------------------------------------------- commands

    private static void registerCommands(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(
            LiteralArgumentBuilder.<FabricClientCommandSource>literal("inf")
                .executes(ctx -> {
                    reply(ctx.getSource(), "Inf Stock: " + (enabled ? "ON" : "OFF")
                            + " | colors: " + (checkColors ? "ON" : "OFF"), enabled);
                    return 1;
                })
                .then(LiteralArgumentBuilder.<FabricClientCommandSource>literal("on")
                    .executes(ctx -> {
                        enabled = true;
                        reply(ctx.getSource(), "Inf Stock: ON", true);
                        return 1;
                    }))
                .then(LiteralArgumentBuilder.<FabricClientCommandSource>literal("off")
                    .executes(ctx -> {
                        enabled = false;
                        sendAt = -1L;
                        reply(ctx.getSource(), "Inf Stock: OFF", false);
                        return 1;
                    }))
                .then(LiteralArgumentBuilder.<FabricClientCommandSource>literal("colors")
                    .then(LiteralArgumentBuilder.<FabricClientCommandSource>literal("on")
                        .executes(ctx -> {
                            checkColors = true;
                            reply(ctx.getSource(), "Color check: ON", true);
                            return 1;
                        }))
                    .then(LiteralArgumentBuilder.<FabricClientCommandSource>literal("off")
                        .executes(ctx -> {
                            checkColors = false;
                            reply(ctx.getSource(), "Color check: OFF", false);
                            return 1;
                        })))
        );
    }

    private static void reply(FabricClientCommandSource source, String text, boolean good) {
        source.sendFeedback(Component.literal(text).withStyle(good ? ChatFormatting.GREEN : ChatFormatting.RED));
    }
}
